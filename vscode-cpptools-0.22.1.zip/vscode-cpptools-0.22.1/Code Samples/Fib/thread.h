void * thread_proc(void* ctx);
